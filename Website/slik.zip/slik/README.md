# Slik
Slik is a terminal based IDE made in go.  
It runs on almost any terminal application out there*.

<p style="font-size: 5px">*slik has been tested on cmd.exe, windows terminal app, Vscode but not on linux terminals yet</p>

<img src="./README_files/cmd.png" alt="Example of text Editor" style="width: 350px; height: 200px">
<img src="./README_files/terminalAppSolorizedDarkTheme.png" alt="Example of text Editor" style="width: 350px; height: 200px">
<img src="./README_files/TerminalAppCustomTheme.png" alt="Example of text Editor" style="width: 350px; height: 200px">
<img src="./README_files/VsCodeTerminal.png" alt="Example of text Editor" style="width: 350px; height: 200px">

It is has general purpose syntax highlighting so there isn't custom syntax highlighting for each language.